#ifndef SYNTH_8BITS_H_
# define SYNTH_8_BITS_H_

//Some macros
#define frequency_to_period(f) (62500 / (f))

/*
#ifdef __cplusplus
extern "C" {
#endif
*/

/*************************************************************************/
/* Here come definitions and prototypes for the Synth_8bits library      */
/* All this stuff is given, without guaranty, and under the BSD licence. */
/*                                 ---                                   */
/* By Jeremy Cochoy                                                      */
/*************************************************************************/

//White noise table, in progmem
extern char white_noise[4096];

/////////////////////////
// Settings / Controls //
/////////////////////////

//Periods, stored after applying the right calculus with frequency_to_period(int)
extern int square1_period;
extern int square2_period;
extern int square3_period;
extern int square4_period;

// 0 = full speed, 255 = slowest (for a tv white noise sound
// use 20, which i the default value)
extern unsigned char noise_speed;

//Output amplitudes. Make sure that the sum of all your amplitudes of synth is < than 256!

extern unsigned char square1_amplitude;
extern unsigned char square2_amplitude;
extern unsigned char square3_amplitude;
extern unsigned char square4_amplitude;

extern unsigned char noise_amplitude;

/*************************************************
* Public Constants, from Tone Lybrary, by B Hagman
*  see : http://code.google.com/p/arduino-tone/source/browse/trunk/Tone.h
*************************************************/

#define NOTE_B0  31
#define NOTE_C1  33
#define NOTE_CS1 35
#define NOTE_D1  37
#define NOTE_DS1 39
#define NOTE_E1  41
#define NOTE_F1  44
#define NOTE_FS1 46
#define NOTE_G1  49
#define NOTE_GS1 52
#define NOTE_A1  55
#define NOTE_AS1 58
#define NOTE_B1  62
#define NOTE_C2  65
#define NOTE_CS2 69
#define NOTE_D2  73
#define NOTE_DS2 78
#define NOTE_E2  82
#define NOTE_F2  87
#define NOTE_FS2 93
#define NOTE_G2  98
#define NOTE_GS2 104
#define NOTE_A2  110
#define NOTE_AS2 117
#define NOTE_B2  123
#define NOTE_C3  131
#define NOTE_CS3 139
#define NOTE_D3  147
#define NOTE_DS3 156
#define NOTE_E3  165
#define NOTE_F3  175
#define NOTE_FS3 185
#define NOTE_G3  196
#define NOTE_GS3 208
#define NOTE_A3  220
#define NOTE_AS3 233
#define NOTE_B3  247
#define NOTE_C4  262
#define NOTE_CS4 277
#define NOTE_D4  294
#define NOTE_DS4 311
#define NOTE_E4  330
#define NOTE_F4  349
#define NOTE_FS4 370
#define NOTE_G4  392
#define NOTE_GS4 415
#define NOTE_A4  440
#define NOTE_AS4 466
#define NOTE_B4  494
#define NOTE_C5  523
#define NOTE_CS5 554
#define NOTE_D5  587
#define NOTE_DS5 622
#define NOTE_E5  659
#define NOTE_F5  698
#define NOTE_FS5 740
#define NOTE_G5  784
#define NOTE_GS5 831
#define NOTE_A5  880
#define NOTE_AS5 932
#define NOTE_B5  988
#define NOTE_C6  1047
#define NOTE_CS6 1109
#define NOTE_D6  1175
#define NOTE_DS6 1245
#define NOTE_E6  1319
#define NOTE_F6  1397
#define NOTE_FS6 1480
#define NOTE_G6  1568
#define NOTE_GS6 1661
#define NOTE_A6  1760
#define NOTE_AS6 1865
#define NOTE_B6  1976
#define NOTE_C7  2093
#define NOTE_CS7 2217
#define NOTE_D7  2349
#define NOTE_DS7 2489
#define NOTE_E7  2637
#define NOTE_F7  2794
#define NOTE_FS7 2960
#define NOTE_G7  3136
#define NOTE_GS7 3322
#define NOTE_A7  3520
#define NOTE_AS7 3729
#define NOTE_B7  3951
#define NOTE_C8  4186
#define NOTE_CS8 4435
#define NOTE_D8  4699
#define NOTE_DS8 4978

/**********
 * A table that contain all those frequencies (89)
 * stored in sram.
 **********/
extern int note_table[];

/**********
 * Give the 8bits index of the previous table, if you know the note
 **********/
#define BNOTE_B0	0
#define BNOTE_C1	1
#define BNOTE_CS1	2
#define BNOTE_D1	3
#define BNOTE_DS1	4
#define BNOTE_E1	5
#define BNOTE_F1	6
#define BNOTE_FS1	7
#define BNOTE_G1	8
#define BNOTE_GS1	9
#define BNOTE_A1	10
#define BNOTE_AS1	11
#define BNOTE_B1	12
#define BNOTE_C2	13
#define BNOTE_CS2	14
#define BNOTE_D2	15
#define BNOTE_DS2	16
#define BNOTE_E2	17
#define BNOTE_F2	18
#define BNOTE_FS2	19
#define BNOTE_G2	20
#define BNOTE_GS2	21
#define BNOTE_A2	22
#define BNOTE_AS2	23
#define BNOTE_B2	24
#define BNOTE_C3	25
#define BNOTE_CS3	26
#define BNOTE_D3	27
#define BNOTE_DS3	28
#define BNOTE_E3	29
#define BNOTE_F3	30
#define BNOTE_FS3	31
#define BNOTE_G3	32
#define BNOTE_GS3	33
#define BNOTE_A3	34
#define BNOTE_AS3	35
#define BNOTE_B3	36
#define BNOTE_C4	37
#define BNOTE_CS4	38
#define BNOTE_D4	39
#define BNOTE_DS4	40
#define BNOTE_E4	41
#define BNOTE_F4	42
#define BNOTE_FS4	43
#define BNOTE_G4	44
#define BNOTE_GS4	45
#define BNOTE_A4	46
#define BNOTE_AS4	47
#define BNOTE_B4	48
#define BNOTE_C5	49
#define BNOTE_CS5	50
#define BNOTE_D5	51
#define BNOTE_DS5	52
#define BNOTE_E5	53
#define BNOTE_F5	54
#define BNOTE_FS5	55
#define BNOTE_G5	56
#define BNOTE_GS5	57
#define BNOTE_A5	58
#define BNOTE_AS5	59
#define BNOTE_B5	60
#define BNOTE_C6	61
#define BNOTE_CS6	62
#define BNOTE_D6	63
#define BNOTE_DS6	64
#define BNOTE_E6	65
#define BNOTE_F6	66
#define BNOTE_FS6	67
#define BNOTE_G6	68
#define BNOTE_GS6	69
#define BNOTE_A6	70
#define BNOTE_AS6	71
#define BNOTE_B6	72
#define BNOTE_C7	73
#define BNOTE_CS7	74
#define BNOTE_D7	75
#define BNOTE_DS7	76
#define BNOTE_E7	77
#define BNOTE_F7	78
#define BNOTE_FS7	79
#define BNOTE_G7	80
#define BNOTE_GS7	81
#define BNOTE_A7	82
#define BNOTE_AS7	83
#define BNOTE_B7	84
#define BNOTE_C8	85
#define BNOTE_CS8	86
#define BNOTE_D8	87
#define BNOTE_DS8	88

//////////////
//Prototypes//
//////////////

//Initialisation (call it in void setup() )
void synth_setup();

//Play some chord 'like' an orgue
// (do not forget to delay a little time after...)
void play_org(int f);

//Play waves from the sea/beach
// (just call it in a while(true) )
void play_seawave();

/*
#ifdef __cplusplus
}
#endif
*/

#endif /* !SYNTH_8BITS_H_ */

