#include <avr/io.h>
#include <avr/interrupt.h>

#include <Arduino.h>

#include "Synth_8bits.h"
#include "white_noise.h"

//Periods, stored after applying the right calculus with frequency_to_period(int)
int square1_period = 0;
int square2_period = 0;
int square3_period = 0;
int square4_period = 0;

// 0 = full speed, 255 = slowest (for a tv white noise sound, use 20
unsigned char noise_speed = 20;

//Output amplitudes. Make sure that the sum of all your amplitudes of synth is < than 256!

unsigned char square1_amplitude = 0;
unsigned char square2_amplitude = 0;
unsigned char square3_amplitude = 0;
unsigned char square4_amplitude = 0;

unsigned char noise_amplitude = 0;

///////////////////////
// PRIVATE VARIABLES //
///////////////////////
//Counters used to synthetise at the right frequency

int square1_id = 0;
int square2_id = 0;
int square3_id = 0;
int square4_id = 0;

int noise_id = 0;

unsigned char noise_delay = 0;

//Note table
int note_table[] = {31, 33, 35, 37, 39, 41, 44, 46, 49, 52, 55, 58, 62, 65, 69, 73, 78, 82, 87, 93, 98,
  104, 110, 117, 123, 131, 139, 147, 156, 165, 175, 185, 196, 208, 220, 233, 247, 262, 277, 294, 311, 330,
  349, 370, 392, 415, 440, 466, 494, 523, 554, 587, 622, 659, 698, 740, 784, 831, 880, 932, 988, 1047, 1109,
  1175, 1245, 1319, 1397, 1480, 1568, 1661, 1760, 1865, 1976, 2093, 2217, 2349, 2489, 2637, 2794, 2960, 3136,
  3322, 3520, 3729, 3951, 4186, 4435, 4699, 4978};

void synth_setup()
{
  //Fast PWM
  //COM2A 1:0 = 2 -> not inverted
  //WGM0 2:1:0 = 3 -> FAST PWM
  TCCR2A = _BV(COM2A1) | _BV(WGM01) | _BV(WGM00);
  
  //Timer setting
  //Setup the mask
  TIMSK2 = _BV(TOIE2);
  //Set N=1 : no divisor
  TCCR2B = 0 << CS22 | 0 << CS21 | 1 << CS20;
  
  //OC2A[The pwm pin] is pin B3(~11)
  DDRB = _BV(DDB3);
}

/*
// OLD C-CODE
// TOO SLOW TO BE USED AT THIS FREQUENCY :(

void inline compute_square_wave(int &out, int &square_id, unsigned char &square_amplitude, int &square_period)
{
  square_id = square_id & (4096 - 1);
  if (square_id > 2048)
    out += square_amplitude;
  //Center the square wave
  out -= square_amplitude >> 1;
  square_id += square_period;
};

//The synthetiser
ISR(TIMER2_OVF_vect)
{
   int out = 128;

  //Square waves
  compute_square_wave(out, square1_id, square1_amplitude, square1_period);
  compute_square_wave(out, square2_id, square2_amplitude, square2_period);
  //compute_square_wave(out, square3_id, square3_amplitude, square3_period);
  
  OCR2A = out;
}
*/

// ------------ SQUARE WAVE GENERATOR -----------------------+
#define square_wave0(amplitude, period, id)                   \
      asm volatile (                                         \
    	"lds r24, " period "\n" /* load period low */        \
	"lds r25, (" period ")+1\n" /* load period high */   \
        "lds r30, " id "\n" /* load id low */                \
        "lds r31, (" id ")+1\n" /* load id high */           \
        "lds r28, " amplitude "\n" /* load amplitude */      \
                                                             \
        /* square1_id &= (8192-1) ; 4096-1 = 0xFFF */        \
        "andi r31, hi8(8191)\n"                              \
  		                                             \
        /* if (r >= 4096) goto .Lb_<something> */            \
        "cpi r31, hi8(4096)\n"                               \
        "brge .Lb_%=\n"                                      \
                                                             \
        /* Add the amplitude */                              \
        "add r23, r28\n"                                     \
                                                             \
        ".Lb_%=:\n"                                          \
                                                             \
        /* out -= square_amplitude/2 */                      \
        "lsr r28\n" /* logical shift right = >> 1 */         \
        "sub r23, r28\n"                                     \
                                                             \
        /* square_id += square_period */                     \
        "add r30,r24\n"                                      \
        "adc r31,r25\n"                                      \
        "sts " id ",r30\n"                                   \
        "sts (" id ")+1,r31\n"                               \
        ::)

/* NEW ONE  */
// ------------ SQUARE WAVE GENERATOR -----------------------+
#define square_wave(amplitude, period, id)                   \
      asm volatile (                                         \
    	"lds r24, " period "\n" /* load period low */        \
	"lds r25, (" period ")+1\n" /* load period high */   \
        "lds r30, " id "\n" /* load id low */                \
        "lds r31, (" id ")+1\n" /* load id high */           \
        "lds r28, " amplitude "\n" /* load amplitude */      \
                                                             \
        /* if (id < period) goto .do_not_reset_<something> */\
        "cp r30, r24\n"                                      \
        "cpc r31, r25\n"                                     \
        "brlt .do_not_reset_%=\n"                            \
        /* Reset id and go to the end of the function */     \
        "ldi r30,0\n" /* id = 0 */                           \
        "ldi r31,0\n"                                        \
        "sts " id ",r30\n"                                   \
        "sts (" id ")+1,r31\n"                               \
        "rjmp .end_%=\n"                                     \
        ".do_not_reset_%=:\n"                                \
                                                             \
        /* if (id >= period/2) goto .Lb_<something> */       \
        "lsr r25\n"                                          \
        "ror r24\n"                                          \
        "cp r30, r24\n"                                      \
        "cpc r31, r25\n"                                     \
        "brge .Lb_%=\n"                                      \
                                                             \
        /* Add the amplitude */                              \
        "add r23, r28\n"                                     \
                                                             \
        ".Lb_%=:\n"                                          \
                                                             \
        /* out -= square_amplitude/2 */                      \
        "lsr r28\n" /* logical shift right = >> 1 */         \
        "sub r23, r28\n"                                     \
                                                             \
        /* square_id += 1 */                                 /*
        // You can also use : 
        "ldi r24, 1\n"                                       \
        "ldi r25, 0\n"                                       \
        "add r30,r24\n"                                      \
        "adc r31,r25\n"                                      \*/\
        "adiw r30, 1\n"                                      \
        "sts " id ",r30\n"                                   \
        "sts (" id ")+1,r31\n"                               \
                                                             \
        ".end_%=:\n"                                         \
        ::)

ISR(TIMER2_OVF_vect, ISR_NAKED)
{	
  asm volatile (
    "push r30\n" //square_id low
    "push r31\n" //square_id high
    "push r28\n" //square_amplitude
    "push r23\n" //out
    "push r24\n" //square_period low
    "push r25\n" //square_period high
    "in r23, __SREG__\n"
    "push r23\n"
    
    "ldi r23, lo8(128)\n" //out=128
    );
                
  //---------------
  //-  SQUARE  1  -
  //---------------
  square_wave("square1_amplitude", "square1_period", "square1_id");
  //---------------
  
  //---------------
  //-  SQUARE  2  -
  //---------------
  square_wave("square2_amplitude", "square2_period", "square2_id");
  //---------------
  
  //---------------
  //-  SQUARE  3  -
  //---------------
  square_wave("square3_amplitude", "square3_period", "square3_id");
  //---------------
  
  //---------------
  //-  SQUARE  4  -
  //---------------
  square_wave("square4_amplitude", "square4_period", "square4_id");
  //---------------
  
  asm volatile (
    //if (noise_amplitude) : when there is no noise (in fact often ;) )
    // we skip all these code an prevent a lot's of cycles.
    "lds r30, noise_amplitude\n"
    "cpi r30, 0\n"

    "breq .no_noise\n"
    
    //Load noise id
    "lds r24, noise_id\n"
    "lds r25, (noise_id)+1\n"
    
    //Load white_noise addr
    "ldi r30, lo8(white_noise)\n"
    "ldi r31, hi8(white_noise)\n"

    //Sum noise_id and white_noise
    "add r30, r24\n"
    "adc r31, r25\n"
    
    //Load noise value into r28
    "lpm r28, Z\n"
    
    //We will use mult!
    "push r0\n"
    "push r1\n"

    //Load noise amplitude
    "lds r30, noise_amplitude\n"
     
    //r1:r0 = white_noise[noise_id] * noise_amplitude
    "mul r28, r30\n"
    
    //Add white_noise[noise_id] to out
    // (We want to divide r1:r0 by 255, but it's easyer to divide by 256, i.e.
    // only take the hight part r1 of the result :)
    "add r23, r1\n"
    
    "pop r1\n"
    "pop r0\n"
    
    //Load the delay value
    "lds r30, noise_delay\n"
    "lds r31, noise_speed\n"
    
    //If noise_delay <= noise_speed
    "cp r30, r31\n"
    "brge .inc_noise\n"
    //Increment noise_delay
    "inc r30\n"
    "rjmp .endif_delay_lt_speed\n"
    
    //else
    ".inc_noise:\n"
    //noise_delay = 0
    "ldi r30, lo8(0)\n"

    //Increment noise_id of 1
    "ldi r28, 1\n"
    "add r24, r28\n"
    "ldi r28, 0\n"
    "adc r25, r28\n"
    "andi r25, hi8(4095)\n"
    //Store the new noise_id value
    "sts noise_id, r24\n"
    "sts (noise_id)+1, r25\n"

    ".endif_delay_lt_speed:\n"
    //Store the new noise_delay value
    "sts noise_delay, r30\n"
    
    //endif (noise_activated)
    ".no_noise:\n");

  asm volatile (
    //Update OCR2A with the out(r23) value calculated
    "ldi r30,lo8(179)\n"
    "ldi r31,hi8(179)\n"
    "st Z, r23\n"
    
    //pop saved registers
    "pop r23\n"
    "out __SREG__, r23\n"
    "pop r25\n"
    "pop r24\n"
    "pop r23\n"
    "pop r28\n"
    "pop r31\n"
    "pop r30\n");
  reti();
}


///////////////////////////////////////////////
// Funny functions, used to make some noises //
///////////////////////////////////////////////


void play_org(int f)
{
    square1_amplitude = 100;
    square1_period = frequency_to_period(f);
  
    square2_amplitude = 60;
    square2_period = frequency_to_period(f*2);
  
    square3_amplitude = 40;
    square3_period = frequency_to_period(f*4);
  
    square4_amplitude = 20;
    square4_period = frequency_to_period(f*8);
}

void play_seawave()
{
  for (; noise_amplitude < 120;)
  {
   noise_amplitude+=2;
   delay(40);
  }
  for (; noise_amplitude > 10;)
  {
   noise_amplitude-=4;
   delay(40);
  }
  delay(700);
}


